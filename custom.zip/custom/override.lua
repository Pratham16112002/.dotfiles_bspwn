-- overriding default plugin configs!

local M = {}

M.treesitter = {
  ensure_installed = {
    "lua",
    "html",
    "css",
    "markdown",
    "jsonc",
    "c",
    "cpp",
    "typescript",
    "javascript",
    "rust",
    "kotlin",
    "java",
  },
}

M.nvimtree = {
  git = {
    enable = true,
  },

  renderer = {
    highlight_git = true,
    icons = {
      show = {
        git = true,
      },
    },
  },
}

M.blankline = {
  filetype_exclude = {
    "help",
    "terminal",
    "alpha",
    "packer",
    "lspinfo",
    "TelescopePrompt",
    "TelescopeResults",
    "nvchad_cheatsheet",
    "lsp-installer",
    "norg",
    "",
  },
}

M.mason = {
  ensure_installed = {
    "clangd",
    "eslint-lsp",
    "bash-language-server",
    -- lua stuff
    "lua-language-server",
    "stylua",
    -- web dev
    "css-lsp",
    "html-lsp",
    "typescript-language-server",
    "emmet-ls",
    "json-lsp",

    -- shell
    "shfmt",
    "shellcheck",
    "cpptools",
    "codespell",
    "cpplint",
    "flake8",
    "prettier",
    "prettierd",
    "sql-formatter",
    "python-lsp-server",
    "sqlls",
  },
}
return M
